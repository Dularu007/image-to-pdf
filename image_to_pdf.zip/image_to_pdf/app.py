from flask import Flask, render_template, request, send_file
from PIL import Image
import os
import uuid

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'output'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    files = request.files.getlist('images')
    image_list = []

    for file in files:
        if file.filename != '':
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            image = Image.open(filepath).convert('RGB')
            image_list.append(image)

    if not image_list:
        return "No images uploaded"

    output_path = os.path.join(OUTPUT_FOLDER, f"{uuid.uuid4()}.pdf")
    first_image, rest = image_list[0], image_list[1:]
    first_image.save(output_path, save_all=True, append_images=rest)

    return send_file(output_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
